from utils import labelme2voc
from utils import voc_trainval


if __name__ == '__main__':
    path='VOCdevkit'
    train_percent=0.9
    labelme2voc.label2voc()
    voc_trainval.voc_trainval(path,train_percent)